<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Seoulwebdesign\Kakaopay\Gateway\Request;

use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Payment\Gateway\Helper;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Helper\Formatter;
use Magento\Sales\Model\Order\Payment;
use Magento\Store\Model\StoreManagerInterface;
use Seoulwebdesign\Base\Helper\Currency;
use Seoulwebdesign\Kakaopay\Helper\ConfigHelper;
use Seoulwebdesign\Kakaopay\Helper\Constant;
use Seoulwebdesign\Kakaopay\Model\Ui\ConfigProvider;

/**
 * Class RefundDataBuilder
 * @package Seoulwebdesign\Kakaopay\Gateway\Request
 */
class CaptureDataBuilder implements BuilderInterface
{
    use Formatter;

    /**
     * Builds ENV request
     *
     * @param array $buildSubject
     * @return array
     */
    public function build(array $buildSubject)
    {
        $data = [
            'cid' => $buildSubject['cid'],
            'tid' => $buildSubject['tid'],
            'partner_order_id' => $buildSubject['partner_order_id'],
            'partner_user_id' =>  $buildSubject['partner_user_id'],
            'pg_token' => $buildSubject['pg_token']
        ];

        return $data;
    }
}
