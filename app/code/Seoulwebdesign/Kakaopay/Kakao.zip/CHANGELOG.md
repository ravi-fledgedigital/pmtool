## Changelog

## [2.0.1] - 2022-04-09
### Fix
- Fix order status after the capture

## [2.0.0] - 2021-08-06
### Update
- Update to use payment gateway command

## [1.0.7] - 2021-08-06
### Fix
- Only send order email after payment success

## [1.0.6] - 2021-08-06
### Fix
- Fix order item qty, fix dependency injection

## [1.0.4] - 2021-07-28
### Fix
- Keep the cart if user cancel payment

## [1.0.3] - 2021-07-27
### Added
- Add mobile dectect

## [1.0.2] - 2021-07-25
### Added
- Mobile redirect url
- Keep the cart if user cancel payment

## [1.0.1] - 2021-07-13
### Fix
- Fix config to support store scope
