<?php

namespace Seoulwebdesign\Kakaopay\Controller\Checkout;

use Magento\Framework\Controller\ResultFactory;
use Seoulwebdesign\Kakaopay\Helper\Constant;

class Cancel extends \Seoulwebdesign\Kakaopay\Controller\Checkout
{
    public function execute()
    {

        try {
            $params = $this->getRequest()->getParams();
            $this->logger->addDebug('Cancel-param-' . print_r($params, true));
            $order = $this->checkoutSession->getLastRealOrder();
            if (!$order) {
                throw new \Magento\Framework\Exception\LocalizedException(__(" "));
            }
            $payment = $order->getPayment();
            if (!$payment) {
                throw new \Magento\Framework\Exception\LocalizedException(__(" "));
            }
            $dataCheck = [
                'cid' => $this->configHelper->getCID(),
                'tid' => $payment->getAdditionalInformation(Constant::KAKAOPAY_RESPONSE_TID)
            ];
            $responseCheck = $this->configHelper->sendCurl(Constant::KAKAOPAY_PAYMENT_CHECK, $dataCheck, "POST");
            if ($responseCheck && isset($responseCheck['status']) && $responseCheck['status'] == 'QUIT_PAYMENT') {
                $order->cancel();
                $order->addCommentToStatusHistory(__('Canceled By Customer'));
                $order->save();
                $this->checkoutSession->restoreQuote();
                $this->messageManager->addErrorMessage(__("You canceled the payment. The order is canceled"));
                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                return $resultRedirect->setPath('checkout/cart');
            } else {
                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                return $resultRedirect->setPath('');
            }
        } catch (\Exception $exception) {
            $this->messageManager->addErrorMessage(__("Something went wrong. Please try again"));
            $this->logger->addDebug('Cancel-' . $exception->getMessage());
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            return $resultRedirect->setPath('checkout/cart');
        }
    }
}
