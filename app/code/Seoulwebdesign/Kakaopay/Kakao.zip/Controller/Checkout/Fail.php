<?php

namespace Seoulwebdesign\Kakaopay\Controller\Checkout;

use Magento\Framework\Controller\ResultFactory;

class Fail extends \Seoulwebdesign\Kakaopay\Controller\Checkout
{
    public function execute()
    {
        $params = $this->getRequest()->getParams();
        $this->logger->addDebug('Fail' . print_r($params, true));
        $this->messageManager->addErrorMessage(__("Something wentwrong. Your payment was rejected. Please try again!"));
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('checkout/cart');
    }
}
