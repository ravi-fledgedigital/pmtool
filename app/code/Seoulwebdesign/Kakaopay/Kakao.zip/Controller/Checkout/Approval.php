<?php

namespace Seoulwebdesign\Kakaopay\Controller\Checkout;

use Magento\Framework\Controller\ResultFactory;
use Seoulwebdesign\Kakaopay\Helper\Constant;
use Seoulwebdesign\Kakaopay\Model\Ui\ConfigProvider;

class Approval extends \Seoulwebdesign\Kakaopay\Controller\Checkout
{


    public function execute()
    {
        $params = $this->getRequest()->getParams();
        $this->logger->addDebug('Approval-param-' . print_r($params, true));
        $order = $this->checkoutSession->getLastRealOrder();
        if (!$order) {
            throw new \Magento\Framework\Exception\LocalizedException(__(" "));
        }
        /** @var \Magento\Sales\Model\Order\Payment $payment */

        $payment = $order->getPayment();
        if (!$payment) {
            throw new \Magento\Framework\Exception\LocalizedException(__(" "));
        }
        $tid = $payment->getAdditionalInformation(Constant::KAKAOPAY_RESPONSE_TID);
        $dataCheck = [
            'cid' => $this->configHelper->getCID(),
            'tid' => $tid
        ];
        $responseCheck = $this->configHelper->sendCurl(Constant::KAKAOPAY_PAYMENT_CHECK, $dataCheck, "POST");
        /*
         (
            [tid] => T2928260311251793012
            [cid] => C626420035
            [status] => AUTH_PASSWORD
            [partner_order_id] => 000000422
            [partner_user_id] => mods2003@gmail.com
            [payment_method_type] => MONEY
            [item_name] => 결제 테스트  Payment Test -1
            [item_code] => 000000422
            [quantity] => 0
            [amount] => Array
                (
                    [total] => 1000
                    [tax_free] => 0
                    [vat] => 0
                )

            [cancel_available_amount] => Array
                (
                    [total] => 1000
                    [tax_free] => 0
                    [vat] => 0
                )

            [canceled_amount] => Array
                (
                    [total] => 0
                    [tax_free] => 0
                    [vat] => 0
                )

            [created_at] => 2021-08-09T01:45:34
        )
         */
        $this->logger->addDebug(print_r($responseCheck, true));
        if ($responseCheck && isset($responseCheck['status']) && $responseCheck['status'] == 'AUTH_PASSWORD') {
            $tid =  $responseCheck['tid'];
            try {
                $commandExecutor = $this->commandManagerPool->get(ConfigProvider::CODE);
                $token = $params['pg_token'];
                $commandExecutor->executeByCode(
                    'capture',
                    $order->getPayment(),
                    [
                        'cid' => strval($this->configHelper->getCID()),
                        'tid' => $tid,
                        'partner_order_id' => $responseCheck['partner_order_id'],
                        'partner_user_id' =>  $responseCheck['partner_user_id'],
                        'pg_token' => $token,
                    ]
                );

                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                return $resultRedirect->setPath('checkout/onepage/success');
            } catch (\Throwable $exception) {

                $this->messageManager->addErrorMessage(__($exception->getMessage()));
                $this->_redirect('checkout/cart');
                $this->logger->addDebug('Approval-' . $exception->getMessage());
            }
        } else {
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('');
            return $resultRedirect;
        }
    }
    public function execute1()
    {
        try {
            $params = $this->getRequest()->getParams();
            $this->logger->addDebug('Approval-param-' . print_r($params, true));
            /** @var \Magento\Sales\Model\Order $order */
            $order = $this->checkoutSession->getLastRealOrder();
            if (!$order) {
                throw new \Magento\Framework\Exception\LocalizedException(__(" "));
            }
            /** @var \Magento\Sales\Model\Order\Payment $payment */

            $payment = $order->getPayment();
            if (!$payment) {
                throw new \Magento\Framework\Exception\LocalizedException(__(" "));
            }
            $tid = $payment->getAdditionalInformation(Constant::KAKAOPAY_RESPONSE_TID);
            $dataCheck = [
                'cid' => $this->configHelper->getCID(),
                'tid' => $tid
            ];
            $responseCheck = $this->configHelper->sendCurl(Constant::KAKAOPAY_PAYMENT_CHECK, $dataCheck, "POST");
            $this->logger->addDebug(print_r($responseCheck, true));
            if ($responseCheck && isset($responseCheck['status']) && $responseCheck['status'] == 'AUTH_PASSWORD') {
                $payment->setAdditionalInformation(Constant::KAKAOPAY_RESPONSE_TOKEN, $params['pg_token']);
                $payment->setAdditionalInformation(Constant::KAKAOPAY_RESPONSE_POI, $responseCheck['partner_order_id']);
                $payment->setAdditionalInformation(Constant::KAKAOPAY_RESPONSE_PUI, $responseCheck['partner_user_id']);
                $magentoOrderId = $order->getIncrementId();
                $quoteId = $order->getQuoteId();
                $this->checkoutSession->setLastQuoteId($quoteId)->setLastSuccessQuoteId($quoteId);
                /** @var \Magento\Sales\Model\Order\Payment $payment */
                $payment
                    ->setShouldCloseParentTransaction(1)
                    ->setIsTransactionClosed(0);
                $payment->setTransactionId($tid);
                $payment->setParentTransactionId($tid);
                $invoice = $order->prepareInvoice();
                $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
                $invoice->register();
                $transaction = $this->_objectManager->create('\\Magento\\Framework\\DB\\Transaction');
                $transaction->addObject($invoice)
                    ->addObject($invoice->getOrder())
                    ->save();
                $order->addStatusHistoryComment("Payment Approved");
                $invoiceSender = $this->_objectManager->create('\Magento\Sales\Model\Order\Email\Sender\InvoiceSender');
                $invoiceSender->send($invoice);
                $order->addStatusHistoryComment(
                    __('Notified customer about invoice #%1.', $invoice->getId())
                )
                    ->setIsCustomerNotified(true);
                $order->save();

                $order = $this->orderProcessing->getOrderByIncrementId($order->getIncrementId());
                $this->orderProcessing->forceSendEmail($order);
                $this->messageManager->addSuccessMessage("Your order (ID: $magentoOrderId) was successful!");
                $this->_redirect('checkout/onepage/success');
            } else {
                $resultRedirect = $this->resultRedirectFactory->create();
                $resultRedirect->setPath('');
                return $resultRedirect;
            }
        } catch (\Exception $exception) {
            $this->messageManager->addErrorMessage(__($exception->getMessage()));
            $this->_redirect('checkout/cart');
            $this->logger->addDebug('Approval-' . $exception->getMessage());
        }
    }
}
