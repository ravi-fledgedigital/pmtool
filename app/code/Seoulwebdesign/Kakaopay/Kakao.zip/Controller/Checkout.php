<?php

namespace Seoulwebdesign\Kakaopay\Controller;

use Magento\Payment\Gateway\Command\CommandManagerPoolInterface;
use Seoulwebdesign\Base\Helper\MobileDetect;

abstract class Checkout extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;
    protected $resultJsonFactory;
    protected $orderFactory;
    protected $jsonFactory;
    protected $configHelper;
    protected $storeManager;
    protected $baseUrl;
    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    protected $quoteRepository;

    public $logger;
    /**
     * @var \Seoulwebdesign\Kakaopay\Model\OrderProcessing
     */
    protected $orderProcessing;
    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\OrderSender
     */
    protected $orderSender;

    /**
     * @var CommandManagerPoolInterface
     */
    protected $commandManagerPool;

    protected $mobileDetect;


    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Payment\Helper\Data $paymentHelper
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Checkout\Helper\Data $checkoutData
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Seoulwebdesign\Kakaopay\Logger\Logger $logger
     * @param \Seoulwebdesign\Kakaopay\Helper\ConfigHelper $configHelper
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     * @param \Seoulwebdesign\Kakaopay\Model\OrderProcessing $orderProcessing
     * @param CommandManagerPoolInterface $commandManagerPool
     * @param MobileDetect $mobileDetect
     * @param array $params
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Payment\Helper\Data $paymentHelper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Checkout\Helper\Data $checkoutData,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Seoulwebdesign\Kakaopay\Logger\Logger $logger,
        \Seoulwebdesign\Kakaopay\Helper\ConfigHelper $configHelper,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        \Seoulwebdesign\Kakaopay\Model\OrderProcessing $orderProcessing,
        CommandManagerPoolInterface $commandManagerPool,
        MobileDetect $mobileDetect,
        $params = []
    ) {
        $this->configHelper = $configHelper;
        $this->logger = $logger;
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->orderSender = $orderSender;
        $this->jsonFactory = $resultJsonFactory;
        $this->storeManager = $storeManager;
        $this->quoteRepository = $quoteRepository;
        $this->orderProcessing = $orderProcessing;
        $this->commandManagerPool = $commandManagerPool;
        $this->mobileDetect = $mobileDetect;
        parent::__construct($context);
        $this->baseUrl = $this->storeManager->getStore()->getBaseUrl();
    }
}
